   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy;Online Library Management System |<a href="isipathanava.6te.net" target="_blank"  > Designed by : Pramudithananda</a> 
                </div>

            </div>
        </div>
    </section>